(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_fa6_index_esm_255038b7.js",
  "static/chunks/node_modules_react-icons_lib_esm_fa2222d7._.js",
  "static/chunks/node_modules_38804d1b._.js",
  "static/chunks/app_components_helper_scroll-to-top_jsx_6fdea831._.js",
  "static/chunks/[root-of-the-server]__c69ad677._.css"
],
    source: "dynamic"
});
