(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lottie-react_build_index_umd_3687723e.js",
  "static/chunks/node_modules_next_dist_b97d7727._.js",
  "static/chunks/node_modules_axios_lib_8ce2d585._.js",
  "static/chunks/node_modules_react-icons_tb_index_esm_91933c46.js",
  "static/chunks/node_modules_react-fast-marquee_dist_index_645b42cd.js",
  "static/chunks/_c2f6976c._.js"
],
    source: "dynamic"
});
