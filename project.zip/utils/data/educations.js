export const educations = [
  {
    id: 1,
    title: "Master’s in Software Engineering",
    duration: "2024 - Present",
    institution: "Mälardalen University, Västerås, Sweden",
  },
  {
    id: 2,
    title: "BSc (Hons) in Computer Engineering",
    duration: "2018 - 2022",
    institution: "University of Sri Jayewardenepura, Sri Lanka",
  },
  {
    id: 3,
    title: "G.C.E. Advanced Level Examination",
    duration: "2016",
    institution: "Rajapaksha Central College, Weeraketiya, Sri Lanka",
  }
]