export const experiences = [
  {
    id: 1,
    title: "Software Engineer",
    company: "Creative Software, Colombo, Sri Lanka",
    duration: "(2022 - 2025)"
  },
  {
    id: 2,
    title: "Software Engineering Intern",
    company: "Creative Software, Colombo, Sri Lanka",
    duration: "(2022 - 2023)"
  }
]